module.exports = {
    aliases: {
        
    },
    mappings: {
    }
};
